<?php
echo '<h1>404: File not found!</h1>';
?>